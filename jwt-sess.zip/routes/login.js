var express = require('express');
var router = express.Router();
var passport = require('passport');
var jwt = require('jsonwebtoken');

router.get('/', function(req, res, next) {
    if (req.isAuthenticated()) {
        res.redirect('/');
    } else {
        res.render('login', { });
    }
});



router.post('/', function(req, res, next) {
    passport.authenticate('jwt', function(err, user, info) {

        if (err) return next(err);

        if (!req.body.username) {
            console.log(err || info);
            return res.redirect('/login')
        }

        /*
        req.logIn(user, function(err) {
            if (err) return next(err);
            return res.redirect('/');
        });
        */
        const payload = req.body.username;
        const token = jwt.sign(payload, 'secret');
        console.log('=========token = ' + token);
        if (!token) {
            console.log(err || info);
            return res.redirect('/login');
        } else {
            return res.json('', {accessToken: token});
        }

    })(req, res, next);
});

module.exports = router;